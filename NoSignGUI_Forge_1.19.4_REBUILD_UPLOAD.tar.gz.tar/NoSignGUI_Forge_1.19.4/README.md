# NoSignGUI — Forge 1.19.4

Forge port project based on the supplied NoSignGUI source.

## Target
- Minecraft Java 1.19.4
- Minecraft Forge 45.2.0
- Java 17

## Build from a phone with GitHub Actions
1. Extract this ZIP on your phone.
2. Create a new repository on GitHub.
3. Upload the **contents** of the extracted `NoSignGUI_Forge_1.19.4` folder to the repository root (including the hidden `.github` folder).
4. Open the repository's **Actions** tab.
5. Select **Build NoSignGUI Forge 1.19.4** and press **Run workflow**. A push to `main` or `master` also starts a build automatically.
6. When the run finishes successfully, open it and download the artifact named `NoSignGUI-Forge-1.19.4`.
7. Extract the artifact ZIP. Put the resulting `.jar` into the PojavLauncher instance's `mods` folder for Forge 1.19.4.

Do not upload passwords, access tokens, or private account information. The workflow only builds the source and uploads the resulting JAR as a temporary artifact.

## Local build
With JDK 17 and internet access, run `./gradlew build` (Linux/macOS) or `gradlew.bat build` (Windows). The output is in `build/libs/`.

## Important testing note
A successful Gradle build proves the project compiles and packages. It does not by itself prove the mod works in-game. Test it in a separate Forge 1.19.4 instance before using it in a main world.
