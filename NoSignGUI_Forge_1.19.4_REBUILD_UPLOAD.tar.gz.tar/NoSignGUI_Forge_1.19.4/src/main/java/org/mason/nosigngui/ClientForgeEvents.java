package org.mason.nosigngui;

import net.minecraft.ChatFormatting;
import net.minecraft.client.Minecraft;
import net.minecraft.network.chat.Component;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = NoSignGUI.MOD_ID, value = Dist.CLIENT, bus = Mod.EventBusSubscriber.Bus.FORGE)
public final class ClientForgeEvents {
    private ClientForgeEvents() {}

    @SubscribeEvent
    public static void onClientTick(TickEvent.ClientTickEvent event) {
        if (event.phase != TickEvent.Phase.END || ClientModEvents.toggleKey == null
                || !ClientModEvents.toggleKey.consumeClick()) {
            return;
        }

        NoSignGUI.toggleSignGui();
        boolean allowed = NoSignGUI.isSignGuiEnabled();
        Minecraft minecraft = Minecraft.getInstance();
        if (minecraft.player != null) {
            Component message = Component.translatable(
                    allowed ? "message.nosigngui.disabled" : "message.nosigngui.enabled"
            ).withStyle(allowed ? ChatFormatting.RED : ChatFormatting.GREEN);
            minecraft.player.displayClientMessage(message, true);
        }
    }
}
