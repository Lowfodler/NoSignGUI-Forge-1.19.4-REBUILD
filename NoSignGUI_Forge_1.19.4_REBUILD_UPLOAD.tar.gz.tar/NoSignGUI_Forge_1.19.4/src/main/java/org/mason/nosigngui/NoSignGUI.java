package org.mason.nosigngui;

import net.minecraftforge.fml.common.Mod;

@Mod(NoSignGUI.MOD_ID)
public final class NoSignGUI {
    public static final String MOD_ID = "nosigngui";

    // true = normal sign editor behavior; false = NoSignGUI blocks the editor.
    private static boolean signGuiEnabled = true;

    public static boolean isSignGuiEnabled() {
        return signGuiEnabled;
    }

    public static void toggleSignGui() {
        signGuiEnabled = !signGuiEnabled;
    }
}
