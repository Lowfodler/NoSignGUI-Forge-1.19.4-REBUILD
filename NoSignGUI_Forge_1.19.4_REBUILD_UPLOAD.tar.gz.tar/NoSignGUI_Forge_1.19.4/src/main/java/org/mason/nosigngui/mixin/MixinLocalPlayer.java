package org.mason.nosigngui.mixin;

import net.minecraft.client.player.LocalPlayer;
import net.minecraft.world.level.block.entity.SignBlockEntity;
import org.mason.nosigngui.NoSignGUI;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(LocalPlayer.class)
public abstract class MixinLocalPlayer {
    @Inject(
            method = "openTextEdit(Lnet/minecraft/world/level/block/entity/SignBlockEntity;Z)V",
            at = @At("HEAD"),
            cancellable = true,
            require = 1
    )
    private void nosigngui$blockSignEditor(SignBlockEntity sign, boolean front, CallbackInfo callback) {
        if (!NoSignGUI.isSignGuiEnabled()) {
            callback.cancel();
        }
    }
}
